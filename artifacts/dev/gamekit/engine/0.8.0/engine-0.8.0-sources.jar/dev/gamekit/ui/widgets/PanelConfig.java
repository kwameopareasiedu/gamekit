package dev.gamekit.ui.widgets;

public class PanelConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public dev.gamekit.utils.Picture background;
	public java.awt.Color color;
	public java.lang.Integer cornerRadius;
	public java.lang.Boolean clip;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof PanelConfig panelConfig
			&& java.util.Objects.equals(background, panelConfig.background)
			&& java.util.Objects.equals(color, panelConfig.color)
			&& java.util.Objects.equals(cornerRadius, panelConfig.cornerRadius)
			&& java.util.Objects.equals(clip, panelConfig.clip)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Panel panelWidget = (dev.gamekit.ui.widgets.Panel) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		panelWidget.background = dev.gamekit.utils.Misc.coalesce(background, nearestTheme.panelBackground);
		panelWidget.color = dev.gamekit.utils.Misc.coalesce(color, nearestTheme.panelColor);
		panelWidget.cornerRadius = dev.gamekit.utils.Misc.coalesce(cornerRadius, nearestTheme.panelCornerRadius);
		panelWidget.clip = dev.gamekit.utils.Misc.coalesce(clip, nearestTheme.panelClip);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<PanelConfig> { }
}