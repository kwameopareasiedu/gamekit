package dev.gamekit.ui.widgets;

public class ButtonConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public dev.gamekit.utils.Picture defaultBackground;
	public dev.gamekit.utils.Picture hoverBackground;
	public dev.gamekit.utils.Picture pressedBackground;
	public dev.gamekit.ui.events.MouseEvent.Handler mouseListener;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ButtonConfig buttonConfig
			&& java.util.Objects.equals(defaultBackground, buttonConfig.defaultBackground)
			&& java.util.Objects.equals(hoverBackground, buttonConfig.hoverBackground)
			&& java.util.Objects.equals(pressedBackground, buttonConfig.pressedBackground)
			&& java.util.Objects.equals(mouseListener, buttonConfig.mouseListener)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Button buttonWidget = (dev.gamekit.ui.widgets.Button) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		buttonWidget.defaultBackground = dev.gamekit.utils.Misc.coalesce(defaultBackground, nearestTheme.buttonDefaultBackground);
		buttonWidget.hoverBackground = dev.gamekit.utils.Misc.coalesce(hoverBackground, nearestTheme.buttonHoverBackground);
		buttonWidget.pressedBackground = dev.gamekit.utils.Misc.coalesce(pressedBackground, nearestTheme.buttonPressedBackground);
		buttonWidget.mouseListener = mouseListener;
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<ButtonConfig> { }
}