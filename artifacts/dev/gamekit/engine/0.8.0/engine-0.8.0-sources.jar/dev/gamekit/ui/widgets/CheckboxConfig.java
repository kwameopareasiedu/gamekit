package dev.gamekit.ui.widgets;

public class CheckboxConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public dev.gamekit.utils.Picture defaultIcon;
	public dev.gamekit.utils.Picture toggledIcon;
	public java.lang.Integer iconWidth;
	public java.lang.Integer iconHeight;
	public java.lang.Integer gapSize;
	public java.lang.Boolean toggled;
	public dev.gamekit.ui.events.ChangeEvent.Handler<java.lang.Boolean> changeListener;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof CheckboxConfig checkboxConfig
			&& java.util.Objects.equals(defaultIcon, checkboxConfig.defaultIcon)
			&& java.util.Objects.equals(toggledIcon, checkboxConfig.toggledIcon)
			&& java.util.Objects.equals(iconWidth, checkboxConfig.iconWidth)
			&& java.util.Objects.equals(iconHeight, checkboxConfig.iconHeight)
			&& java.util.Objects.equals(gapSize, checkboxConfig.gapSize)
			&& java.util.Objects.equals(toggled, checkboxConfig.toggled)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Checkbox checkboxWidget = (dev.gamekit.ui.widgets.Checkbox) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		checkboxWidget.defaultIcon = dev.gamekit.utils.Misc.coalesce(defaultIcon, nearestTheme.checkboxDefaultIcon);
		checkboxWidget.toggledIcon = dev.gamekit.utils.Misc.coalesce(toggledIcon, nearestTheme.checkboxToggledIcon);
		checkboxWidget.iconWidth = dev.gamekit.utils.Misc.coalesce(iconWidth, nearestTheme.checkboxIconWidth);
		checkboxWidget.iconHeight = dev.gamekit.utils.Misc.coalesce(iconHeight, nearestTheme.checkboxIconHeight);
		checkboxWidget.gapSize = dev.gamekit.utils.Misc.coalesce(gapSize, nearestTheme.checkboxGapSize);
		checkboxWidget.toggled = dev.gamekit.utils.Misc.coalesce(toggled, nearestTheme.checkboxToggled);
		checkboxWidget.changeListener = changeListener;
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<CheckboxConfig> { }
}