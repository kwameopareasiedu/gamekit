package dev.gamekit.ui.widgets;

public class ProgressConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public dev.gamekit.utils.Picture trackBackground;
	public dev.gamekit.utils.Picture fillBackground;
	public dev.gamekit.utils.Spacing fillMargin;
	public dev.gamekit.ui.widgets.Progress.FillMode fillMode;
	public java.lang.Double minValue;
	public java.lang.Double maxValue;
	public java.lang.Double value;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ProgressConfig progressConfig
			&& java.util.Objects.equals(trackBackground, progressConfig.trackBackground)
			&& java.util.Objects.equals(fillBackground, progressConfig.fillBackground)
			&& java.util.Objects.equals(fillMargin, progressConfig.fillMargin)
			&& java.util.Objects.equals(fillMode, progressConfig.fillMode)
			&& java.util.Objects.equals(minValue, progressConfig.minValue)
			&& java.util.Objects.equals(maxValue, progressConfig.maxValue)
			&& java.util.Objects.equals(value, progressConfig.value)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Progress progressWidget = (dev.gamekit.ui.widgets.Progress) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		progressWidget.trackBackground = dev.gamekit.utils.Misc.coalesce(trackBackground, nearestTheme.progressTrackBackground);
		progressWidget.fillBackground = dev.gamekit.utils.Misc.coalesce(fillBackground, nearestTheme.progressFillBackground);
		progressWidget.fillMargin = dev.gamekit.utils.Misc.coalesce(fillMargin, nearestTheme.progressFillMargin);
		progressWidget.fillMode = dev.gamekit.utils.Misc.coalesce(fillMode, nearestTheme.progressFillMode);
		progressWidget.minValue = dev.gamekit.utils.Misc.coalesce(minValue, nearestTheme.progressMinValue);
		progressWidget.maxValue = dev.gamekit.utils.Misc.coalesce(maxValue, nearestTheme.progressMaxValue);
		progressWidget.value = dev.gamekit.utils.Misc.coalesce(value, nearestTheme.progressValue);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<ProgressConfig> { }
}