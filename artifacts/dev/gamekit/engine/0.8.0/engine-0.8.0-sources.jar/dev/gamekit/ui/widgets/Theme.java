package dev.gamekit.ui.widgets;

@dev.gamekit.annotations.WidgetBuilder
public class Theme extends SingleChildParent {
	public static final Theme DEFAULT = new Theme(null, new ThemeConfig(), Empty.create());

	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.ui.enums.Alignment alignHorizontalAlignment = dev.gamekit.ui.enums.Alignment.START;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.ui.enums.Alignment alignVerticalAlignment = dev.gamekit.ui.enums.Alignment.START;

	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Picture buttonDefaultBackground = dev.gamekit.ui.widgets.Button.DEFAULT_BG;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Picture buttonHoverBackground = dev.gamekit.ui.widgets.Button.DEFAULT_HOVER_BG;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Picture buttonPressedBackground = dev.gamekit.ui.widgets.Button.DEFAULT_PRESSED_BG;

	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Picture checkboxDefaultIcon = dev.gamekit.ui.widgets.Checkbox.DEFAULT_ICON;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Picture checkboxToggledIcon = dev.gamekit.ui.widgets.Checkbox.DEFAULT_TOGGLED_ICON;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer checkboxIconWidth = 24;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer checkboxIconHeight = 24;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer checkboxGapSize = 12;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Boolean checkboxToggled = false;

	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer columnGapSize = 10;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.ui.enums.MainAxisAlignment columnMainAxisAlignment = dev.gamekit.ui.enums.MainAxisAlignment.START;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.ui.enums.CrossAxisAlignment columnCrossAxisAlignment = dev.gamekit.ui.enums.CrossAxisAlignment.START;

	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Picture fieldDefaultBackground = dev.gamekit.ui.widgets.Field.DEFAULT_BG;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Picture fieldFocusBackground = dev.gamekit.ui.widgets.Field.DEFAULT_FOCUS_BG;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Spacing fieldPadding = new dev.gamekit.utils.Spacing(4);

	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.String fieldText = "Hello GameKit";
	@dev.gamekit.annotations.WidgetBuilderField
	public java.awt.Font fieldFont = dev.gamekit.ui.widgets.Text.DEFAULT_FONT;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer fieldFontSize = 20;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Double fieldFontHeightRatio = 1.0;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer fieldFontStyle = dev.gamekit.ui.widgets.Text.PLAIN;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.awt.Color fieldColor = java.awt.Color.WHITE;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.awt.Color fieldBackgroundColor = null;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.ui.enums.Alignment fieldAlignment = dev.gamekit.ui.enums.Alignment.START;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Boolean fieldShadowEnabled = false;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer fieldShadowOffsetX = 0;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer fieldShadowOffsetY = 0;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.awt.Color fieldShadowColor = java.awt.Color.WHITE;

	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer flexGapSize = 10;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.ui.enums.MainAxisAlignment flexMainAxisAlignment = dev.gamekit.ui.enums.MainAxisAlignment.START;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.ui.enums.CrossAxisAlignment flexCrossAxisAlignment = dev.gamekit.ui.enums.CrossAxisAlignment.START;

	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer gapWidth = 8;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer gapHeight = 8;

	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer gridColumnCount = 2;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer gridColumnGapSize = 0;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer gridRowGapSize = 0;

	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.ui.enums.ImageFit imageFit = dev.gamekit.ui.enums.ImageFit.FIT;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.settings.ImageInterpolation imageInterpolation = dev.gamekit.settings.ImageInterpolation.DEFAULT;

	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Double opacityOpacity = 1.0;

	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Spacing paddingPadding = new dev.gamekit.utils.Spacing();

	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Picture panelBackground = dev.gamekit.ui.widgets.Panel.DEFAULT_BG;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.awt.Color panelColor = null;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer panelCornerRadius = 0;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Boolean panelClip = true;

	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Picture progressTrackBackground = dev.gamekit.ui.widgets.Progress.DEFAULT_TRACK_BG;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Picture progressFillBackground = dev.gamekit.ui.widgets.Progress.DEFAULT_FILL_BG;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Spacing progressFillMargin = new dev.gamekit.utils.Spacing(0);
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.ui.widgets.Progress.FillMode progressFillMode = dev.gamekit.ui.widgets.Progress.FillMode.SCALE;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Double progressMinValue = 0.0;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Double progressMaxValue = 100.0;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Double progressValue = 50.0;

	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer rowGapSize = 10;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.ui.enums.MainAxisAlignment rowMainAxisAlignment = dev.gamekit.ui.enums.MainAxisAlignment.START;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.ui.enums.CrossAxisAlignment rowCrossAxisAlignment = dev.gamekit.ui.enums.CrossAxisAlignment.START;

	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Double scaledScale = 1.0;

	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Boolean sizedUseIntrinsicWidth = false;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Boolean sizedUseIntrinsicHeight = false;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Double sizedFractionalWidth = null;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Double sizedFractionalHeight = null;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Double sizedFixedWidth = null;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Double sizedFixedHeight = null;

	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Picture sliderThumbBackground = dev.gamekit.ui.widgets.Slider.DEFAULT_THUMB_BG;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer sliderThumbWidth = 32;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer sliderThumbHeight = 32;

	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Picture sliderTrackBackground = dev.gamekit.ui.widgets.Progress.DEFAULT_TRACK_BG;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Picture sliderFillBackground = dev.gamekit.ui.widgets.Progress.DEFAULT_FILL_BG;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.utils.Spacing sliderFillMargin = new dev.gamekit.utils.Spacing(0);
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.ui.widgets.Progress.FillMode sliderFillMode = dev.gamekit.ui.widgets.Progress.FillMode.SCALE;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Double sliderMinValue = 0.0;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Double sliderMaxValue = 100.0;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Double sliderValue = 50.0;

	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.String textText = "Hello GameKit";
	@dev.gamekit.annotations.WidgetBuilderField
	public java.awt.Font textFont = dev.gamekit.ui.widgets.Text.DEFAULT_FONT;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer textFontSize = 20;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Double textFontHeightRatio = 1.0;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer textFontStyle = dev.gamekit.ui.widgets.Text.PLAIN;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.awt.Color textColor = java.awt.Color.WHITE;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.awt.Color textBackgroundColor = null;
	@dev.gamekit.annotations.WidgetBuilderField
	public dev.gamekit.ui.enums.Alignment textAlignment = dev.gamekit.ui.enums.Alignment.START;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Boolean textShadowEnabled = false;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer textShadowOffsetX = 0;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.lang.Integer textShadowOffsetY = 0;
	@dev.gamekit.annotations.WidgetBuilderField
	public java.awt.Color textShadowColor = java.awt.Color.WHITE;

  public Theme(String key, ThemeConfig config, Widget child) {
    super(key, config, child);
  }

  public static Theme create(String key, ThemeConfig.Updater updater, Widget child) {
    return new Theme(key, Widgets.configureTheme(updater), child);
  }

  public static Theme create(ThemeConfig.Updater updater, Widget child) {
    return new Theme(null, Widgets.configureTheme(updater), child);
  }

  @Override
  protected void performLayout(dev.gamekit.utils.Constraints constraints) {
    child.layout(constraints);

    intrinsicSize.set(child.computedBounds.width, child.computedBounds.height);

    computedBounds.setSize(
      constraints.constrainWidth(intrinsicSize.width),
      constraints.constrainHeight(intrinsicSize.height)
    );
  }

}