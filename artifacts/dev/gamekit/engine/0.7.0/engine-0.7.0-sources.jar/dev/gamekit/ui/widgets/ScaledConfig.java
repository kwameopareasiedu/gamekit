package dev.gamekit.ui.widgets;

public class ScaledConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public java.lang.Double scale;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ScaledConfig scaledConfig
			&& java.util.Objects.equals(scale, scaledConfig.scale)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Scaled scaledWidget = (dev.gamekit.ui.widgets.Scaled) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		scaledWidget.scale = dev.gamekit.utils.Misc.coalesce(scale, nearestTheme.scaledScale);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<ScaledConfig> { }
}