package dev.gamekit.ui.widgets;

public class SizedConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public java.lang.Boolean useIntrinsicWidth;
	public java.lang.Boolean useIntrinsicHeight;
	public java.lang.Double fractionalWidth;
	public java.lang.Double fractionalHeight;
	public java.lang.Double fixedWidth;
	public java.lang.Double fixedHeight;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof SizedConfig sizedConfig
			&& java.util.Objects.equals(useIntrinsicWidth, sizedConfig.useIntrinsicWidth)
			&& java.util.Objects.equals(useIntrinsicHeight, sizedConfig.useIntrinsicHeight)
			&& java.util.Objects.equals(fractionalWidth, sizedConfig.fractionalWidth)
			&& java.util.Objects.equals(fractionalHeight, sizedConfig.fractionalHeight)
			&& java.util.Objects.equals(fixedWidth, sizedConfig.fixedWidth)
			&& java.util.Objects.equals(fixedHeight, sizedConfig.fixedHeight)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Sized sizedWidget = (dev.gamekit.ui.widgets.Sized) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		sizedWidget.useIntrinsicWidth = dev.gamekit.utils.Misc.coalesce(useIntrinsicWidth, nearestTheme.sizedUseIntrinsicWidth);
		sizedWidget.useIntrinsicHeight = dev.gamekit.utils.Misc.coalesce(useIntrinsicHeight, nearestTheme.sizedUseIntrinsicHeight);
		sizedWidget.fractionalWidth = dev.gamekit.utils.Misc.coalesce(fractionalWidth, nearestTheme.sizedFractionalWidth);
		sizedWidget.fractionalHeight = dev.gamekit.utils.Misc.coalesce(fractionalHeight, nearestTheme.sizedFractionalHeight);
		sizedWidget.fixedWidth = dev.gamekit.utils.Misc.coalesce(fixedWidth, nearestTheme.sizedFixedWidth);
		sizedWidget.fixedHeight = dev.gamekit.utils.Misc.coalesce(fixedHeight, nearestTheme.sizedFixedHeight);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<SizedConfig> { }
}