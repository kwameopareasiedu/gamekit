package dev.gamekit.ui.widgets;

public class StackConfig implements dev.gamekit.ui.widgets.Widget.Config {

	@Override
	public boolean equals(Object obj) {
		return obj instanceof StackConfig stackConfig
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Stack stackWidget = (dev.gamekit.ui.widgets.Stack) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<StackConfig> { }
}