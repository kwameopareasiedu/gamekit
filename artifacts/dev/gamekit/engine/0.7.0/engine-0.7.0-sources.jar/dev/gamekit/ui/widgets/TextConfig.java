package dev.gamekit.ui.widgets;

public class TextConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public java.lang.String text;
	public java.awt.Font font;
	public java.lang.Integer fontSize;
	public java.lang.Double fontHeightRatio;
	public java.lang.Integer fontStyle;
	public java.awt.Color color;
	public java.awt.Color backgroundColor;
	public dev.gamekit.ui.enums.Alignment alignment;
	public java.lang.Boolean shadowEnabled;
	public java.lang.Integer shadowOffsetX;
	public java.lang.Integer shadowOffsetY;
	public java.awt.Color shadowColor;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof TextConfig textConfig
			&& java.util.Objects.equals(text, textConfig.text)
			&& java.util.Objects.equals(font, textConfig.font)
			&& java.util.Objects.equals(fontSize, textConfig.fontSize)
			&& java.util.Objects.equals(fontHeightRatio, textConfig.fontHeightRatio)
			&& java.util.Objects.equals(fontStyle, textConfig.fontStyle)
			&& java.util.Objects.equals(color, textConfig.color)
			&& java.util.Objects.equals(backgroundColor, textConfig.backgroundColor)
			&& java.util.Objects.equals(alignment, textConfig.alignment)
			&& java.util.Objects.equals(shadowEnabled, textConfig.shadowEnabled)
			&& java.util.Objects.equals(shadowOffsetX, textConfig.shadowOffsetX)
			&& java.util.Objects.equals(shadowOffsetY, textConfig.shadowOffsetY)
			&& java.util.Objects.equals(shadowColor, textConfig.shadowColor)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Text textWidget = (dev.gamekit.ui.widgets.Text) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		textWidget.text = dev.gamekit.utils.Misc.coalesce(text, nearestTheme.textText);
		textWidget.font = dev.gamekit.utils.Misc.coalesce(font, nearestTheme.textFont);
		textWidget.fontSize = dev.gamekit.utils.Misc.coalesce(fontSize, nearestTheme.textFontSize);
		textWidget.fontHeightRatio = dev.gamekit.utils.Misc.coalesce(fontHeightRatio, nearestTheme.textFontHeightRatio);
		textWidget.fontStyle = dev.gamekit.utils.Misc.coalesce(fontStyle, nearestTheme.textFontStyle);
		textWidget.color = dev.gamekit.utils.Misc.coalesce(color, nearestTheme.textColor);
		textWidget.backgroundColor = dev.gamekit.utils.Misc.coalesce(backgroundColor, nearestTheme.textBackgroundColor);
		textWidget.alignment = dev.gamekit.utils.Misc.coalesce(alignment, nearestTheme.textAlignment);
		textWidget.shadowEnabled = dev.gamekit.utils.Misc.coalesce(shadowEnabled, nearestTheme.textShadowEnabled);
		textWidget.shadowOffsetX = dev.gamekit.utils.Misc.coalesce(shadowOffsetX, nearestTheme.textShadowOffsetX);
		textWidget.shadowOffsetY = dev.gamekit.utils.Misc.coalesce(shadowOffsetY, nearestTheme.textShadowOffsetY);
		textWidget.shadowColor = dev.gamekit.utils.Misc.coalesce(shadowColor, nearestTheme.textShadowColor);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<TextConfig> { }
}