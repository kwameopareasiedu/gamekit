package dev.gamekit.ui.widgets;

public class SpinnerConfig implements dev.gamekit.ui.widgets.Widget.Config {

	@Override
	public boolean equals(Object obj) {
		return obj instanceof SpinnerConfig spinnerConfig
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Spinner spinnerWidget = (dev.gamekit.ui.widgets.Spinner) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<SpinnerConfig> { }
}