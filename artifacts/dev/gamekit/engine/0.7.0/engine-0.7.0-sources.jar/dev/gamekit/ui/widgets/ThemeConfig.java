package dev.gamekit.ui.widgets;

public class ThemeConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public dev.gamekit.ui.enums.Alignment alignHorizontalAlignment;
	public dev.gamekit.ui.enums.Alignment alignVerticalAlignment;
	public dev.gamekit.utils.EngineImage buttonDefaultBackground;
	public dev.gamekit.utils.EngineImage buttonHoverBackground;
	public dev.gamekit.utils.EngineImage buttonPressedBackground;
	public dev.gamekit.utils.EngineImage checkboxDefaultIcon;
	public dev.gamekit.utils.EngineImage checkboxToggledIcon;
	public java.lang.Integer checkboxIconWidth;
	public java.lang.Integer checkboxIconHeight;
	public java.lang.Integer checkboxGapSize;
	public java.lang.Boolean checkboxToggled;
	public java.lang.Integer columnGapSize;
	public dev.gamekit.ui.enums.MainAxisAlignment columnMainAxisAlignment;
	public dev.gamekit.ui.enums.CrossAxisAlignment columnCrossAxisAlignment;
	public dev.gamekit.utils.EngineImage fieldDefaultBackground;
	public dev.gamekit.utils.EngineImage fieldFocusBackground;
	public dev.gamekit.utils.Spacing fieldPadding;
	public java.lang.String fieldText;
	public java.awt.Font fieldFont;
	public java.lang.Integer fieldFontSize;
	public java.lang.Double fieldFontHeightRatio;
	public java.lang.Integer fieldFontStyle;
	public java.awt.Color fieldColor;
	public java.awt.Color fieldBackgroundColor;
	public dev.gamekit.ui.enums.Alignment fieldAlignment;
	public java.lang.Boolean fieldShadowEnabled;
	public java.lang.Integer fieldShadowOffsetX;
	public java.lang.Integer fieldShadowOffsetY;
	public java.awt.Color fieldShadowColor;
	public java.lang.Integer flexGapSize;
	public dev.gamekit.ui.enums.MainAxisAlignment flexMainAxisAlignment;
	public dev.gamekit.ui.enums.CrossAxisAlignment flexCrossAxisAlignment;
	public java.lang.Integer gapWidth;
	public java.lang.Integer gapHeight;
	public java.lang.Integer gridColumnCount;
	public java.lang.Integer gridColumnGapSize;
	public java.lang.Integer gridRowGapSize;
	public dev.gamekit.ui.enums.ImageFit imageFit;
	public dev.gamekit.settings.ImageInterpolation imageInterpolation;
	public java.lang.Double opacityOpacity;
	public dev.gamekit.utils.Spacing paddingPadding;
	public dev.gamekit.utils.EngineImage panelBackground;
	public java.awt.Color panelColor;
	public java.lang.Integer panelCornerRadius;
	public java.lang.Boolean panelClip;
	public dev.gamekit.utils.EngineImage progressTrackBackground;
	public dev.gamekit.utils.EngineImage progressFillBackground;
	public dev.gamekit.utils.Spacing progressFillMargin;
	public dev.gamekit.ui.widgets.Progress.FillMode progressFillMode;
	public java.lang.Double progressMinValue;
	public java.lang.Double progressMaxValue;
	public java.lang.Double progressValue;
	public java.lang.Integer rowGapSize;
	public dev.gamekit.ui.enums.MainAxisAlignment rowMainAxisAlignment;
	public dev.gamekit.ui.enums.CrossAxisAlignment rowCrossAxisAlignment;
	public java.lang.Double scaledScale;
	public java.lang.Boolean sizedUseIntrinsicWidth;
	public java.lang.Boolean sizedUseIntrinsicHeight;
	public java.lang.Double sizedFractionalWidth;
	public java.lang.Double sizedFractionalHeight;
	public java.lang.Double sizedFixedWidth;
	public java.lang.Double sizedFixedHeight;
	public dev.gamekit.utils.EngineImage sliderThumbBackground;
	public java.lang.Integer sliderThumbWidth;
	public java.lang.Integer sliderThumbHeight;
	public dev.gamekit.utils.EngineImage sliderTrackBackground;
	public dev.gamekit.utils.EngineImage sliderFillBackground;
	public dev.gamekit.utils.Spacing sliderFillMargin;
	public dev.gamekit.ui.widgets.Progress.FillMode sliderFillMode;
	public java.lang.Double sliderMinValue;
	public java.lang.Double sliderMaxValue;
	public java.lang.Double sliderValue;
	public java.lang.String textText;
	public java.awt.Font textFont;
	public java.lang.Integer textFontSize;
	public java.lang.Double textFontHeightRatio;
	public java.lang.Integer textFontStyle;
	public java.awt.Color textColor;
	public java.awt.Color textBackgroundColor;
	public dev.gamekit.ui.enums.Alignment textAlignment;
	public java.lang.Boolean textShadowEnabled;
	public java.lang.Integer textShadowOffsetX;
	public java.lang.Integer textShadowOffsetY;
	public java.awt.Color textShadowColor;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ThemeConfig themeConfig
			&& java.util.Objects.equals(alignHorizontalAlignment, themeConfig.alignHorizontalAlignment)
			&& java.util.Objects.equals(alignVerticalAlignment, themeConfig.alignVerticalAlignment)
			&& java.util.Objects.equals(buttonDefaultBackground, themeConfig.buttonDefaultBackground)
			&& java.util.Objects.equals(buttonHoverBackground, themeConfig.buttonHoverBackground)
			&& java.util.Objects.equals(buttonPressedBackground, themeConfig.buttonPressedBackground)
			&& java.util.Objects.equals(checkboxDefaultIcon, themeConfig.checkboxDefaultIcon)
			&& java.util.Objects.equals(checkboxToggledIcon, themeConfig.checkboxToggledIcon)
			&& java.util.Objects.equals(checkboxIconWidth, themeConfig.checkboxIconWidth)
			&& java.util.Objects.equals(checkboxIconHeight, themeConfig.checkboxIconHeight)
			&& java.util.Objects.equals(checkboxGapSize, themeConfig.checkboxGapSize)
			&& java.util.Objects.equals(checkboxToggled, themeConfig.checkboxToggled)
			&& java.util.Objects.equals(columnGapSize, themeConfig.columnGapSize)
			&& java.util.Objects.equals(columnMainAxisAlignment, themeConfig.columnMainAxisAlignment)
			&& java.util.Objects.equals(columnCrossAxisAlignment, themeConfig.columnCrossAxisAlignment)
			&& java.util.Objects.equals(fieldDefaultBackground, themeConfig.fieldDefaultBackground)
			&& java.util.Objects.equals(fieldFocusBackground, themeConfig.fieldFocusBackground)
			&& java.util.Objects.equals(fieldPadding, themeConfig.fieldPadding)
			&& java.util.Objects.equals(fieldText, themeConfig.fieldText)
			&& java.util.Objects.equals(fieldFont, themeConfig.fieldFont)
			&& java.util.Objects.equals(fieldFontSize, themeConfig.fieldFontSize)
			&& java.util.Objects.equals(fieldFontHeightRatio, themeConfig.fieldFontHeightRatio)
			&& java.util.Objects.equals(fieldFontStyle, themeConfig.fieldFontStyle)
			&& java.util.Objects.equals(fieldColor, themeConfig.fieldColor)
			&& java.util.Objects.equals(fieldBackgroundColor, themeConfig.fieldBackgroundColor)
			&& java.util.Objects.equals(fieldAlignment, themeConfig.fieldAlignment)
			&& java.util.Objects.equals(fieldShadowEnabled, themeConfig.fieldShadowEnabled)
			&& java.util.Objects.equals(fieldShadowOffsetX, themeConfig.fieldShadowOffsetX)
			&& java.util.Objects.equals(fieldShadowOffsetY, themeConfig.fieldShadowOffsetY)
			&& java.util.Objects.equals(fieldShadowColor, themeConfig.fieldShadowColor)
			&& java.util.Objects.equals(flexGapSize, themeConfig.flexGapSize)
			&& java.util.Objects.equals(flexMainAxisAlignment, themeConfig.flexMainAxisAlignment)
			&& java.util.Objects.equals(flexCrossAxisAlignment, themeConfig.flexCrossAxisAlignment)
			&& java.util.Objects.equals(gapWidth, themeConfig.gapWidth)
			&& java.util.Objects.equals(gapHeight, themeConfig.gapHeight)
			&& java.util.Objects.equals(gridColumnCount, themeConfig.gridColumnCount)
			&& java.util.Objects.equals(gridColumnGapSize, themeConfig.gridColumnGapSize)
			&& java.util.Objects.equals(gridRowGapSize, themeConfig.gridRowGapSize)
			&& java.util.Objects.equals(imageFit, themeConfig.imageFit)
			&& java.util.Objects.equals(imageInterpolation, themeConfig.imageInterpolation)
			&& java.util.Objects.equals(opacityOpacity, themeConfig.opacityOpacity)
			&& java.util.Objects.equals(paddingPadding, themeConfig.paddingPadding)
			&& java.util.Objects.equals(panelBackground, themeConfig.panelBackground)
			&& java.util.Objects.equals(panelColor, themeConfig.panelColor)
			&& java.util.Objects.equals(panelCornerRadius, themeConfig.panelCornerRadius)
			&& java.util.Objects.equals(panelClip, themeConfig.panelClip)
			&& java.util.Objects.equals(progressTrackBackground, themeConfig.progressTrackBackground)
			&& java.util.Objects.equals(progressFillBackground, themeConfig.progressFillBackground)
			&& java.util.Objects.equals(progressFillMargin, themeConfig.progressFillMargin)
			&& java.util.Objects.equals(progressFillMode, themeConfig.progressFillMode)
			&& java.util.Objects.equals(progressMinValue, themeConfig.progressMinValue)
			&& java.util.Objects.equals(progressMaxValue, themeConfig.progressMaxValue)
			&& java.util.Objects.equals(progressValue, themeConfig.progressValue)
			&& java.util.Objects.equals(rowGapSize, themeConfig.rowGapSize)
			&& java.util.Objects.equals(rowMainAxisAlignment, themeConfig.rowMainAxisAlignment)
			&& java.util.Objects.equals(rowCrossAxisAlignment, themeConfig.rowCrossAxisAlignment)
			&& java.util.Objects.equals(scaledScale, themeConfig.scaledScale)
			&& java.util.Objects.equals(sizedUseIntrinsicWidth, themeConfig.sizedUseIntrinsicWidth)
			&& java.util.Objects.equals(sizedUseIntrinsicHeight, themeConfig.sizedUseIntrinsicHeight)
			&& java.util.Objects.equals(sizedFractionalWidth, themeConfig.sizedFractionalWidth)
			&& java.util.Objects.equals(sizedFractionalHeight, themeConfig.sizedFractionalHeight)
			&& java.util.Objects.equals(sizedFixedWidth, themeConfig.sizedFixedWidth)
			&& java.util.Objects.equals(sizedFixedHeight, themeConfig.sizedFixedHeight)
			&& java.util.Objects.equals(sliderThumbBackground, themeConfig.sliderThumbBackground)
			&& java.util.Objects.equals(sliderThumbWidth, themeConfig.sliderThumbWidth)
			&& java.util.Objects.equals(sliderThumbHeight, themeConfig.sliderThumbHeight)
			&& java.util.Objects.equals(sliderTrackBackground, themeConfig.sliderTrackBackground)
			&& java.util.Objects.equals(sliderFillBackground, themeConfig.sliderFillBackground)
			&& java.util.Objects.equals(sliderFillMargin, themeConfig.sliderFillMargin)
			&& java.util.Objects.equals(sliderFillMode, themeConfig.sliderFillMode)
			&& java.util.Objects.equals(sliderMinValue, themeConfig.sliderMinValue)
			&& java.util.Objects.equals(sliderMaxValue, themeConfig.sliderMaxValue)
			&& java.util.Objects.equals(sliderValue, themeConfig.sliderValue)
			&& java.util.Objects.equals(textText, themeConfig.textText)
			&& java.util.Objects.equals(textFont, themeConfig.textFont)
			&& java.util.Objects.equals(textFontSize, themeConfig.textFontSize)
			&& java.util.Objects.equals(textFontHeightRatio, themeConfig.textFontHeightRatio)
			&& java.util.Objects.equals(textFontStyle, themeConfig.textFontStyle)
			&& java.util.Objects.equals(textColor, themeConfig.textColor)
			&& java.util.Objects.equals(textBackgroundColor, themeConfig.textBackgroundColor)
			&& java.util.Objects.equals(textAlignment, themeConfig.textAlignment)
			&& java.util.Objects.equals(textShadowEnabled, themeConfig.textShadowEnabled)
			&& java.util.Objects.equals(textShadowOffsetX, themeConfig.textShadowOffsetX)
			&& java.util.Objects.equals(textShadowOffsetY, themeConfig.textShadowOffsetY)
			&& java.util.Objects.equals(textShadowColor, themeConfig.textShadowColor)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Theme themeWidget = (dev.gamekit.ui.widgets.Theme) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		themeWidget.alignHorizontalAlignment = dev.gamekit.utils.Misc.coalesce(alignHorizontalAlignment, nearestTheme.alignHorizontalAlignment);
		themeWidget.alignVerticalAlignment = dev.gamekit.utils.Misc.coalesce(alignVerticalAlignment, nearestTheme.alignVerticalAlignment);
		themeWidget.buttonDefaultBackground = dev.gamekit.utils.Misc.coalesce(buttonDefaultBackground, nearestTheme.buttonDefaultBackground);
		themeWidget.buttonHoverBackground = dev.gamekit.utils.Misc.coalesce(buttonHoverBackground, nearestTheme.buttonHoverBackground);
		themeWidget.buttonPressedBackground = dev.gamekit.utils.Misc.coalesce(buttonPressedBackground, nearestTheme.buttonPressedBackground);
		themeWidget.checkboxDefaultIcon = dev.gamekit.utils.Misc.coalesce(checkboxDefaultIcon, nearestTheme.checkboxDefaultIcon);
		themeWidget.checkboxToggledIcon = dev.gamekit.utils.Misc.coalesce(checkboxToggledIcon, nearestTheme.checkboxToggledIcon);
		themeWidget.checkboxIconWidth = dev.gamekit.utils.Misc.coalesce(checkboxIconWidth, nearestTheme.checkboxIconWidth);
		themeWidget.checkboxIconHeight = dev.gamekit.utils.Misc.coalesce(checkboxIconHeight, nearestTheme.checkboxIconHeight);
		themeWidget.checkboxGapSize = dev.gamekit.utils.Misc.coalesce(checkboxGapSize, nearestTheme.checkboxGapSize);
		themeWidget.checkboxToggled = dev.gamekit.utils.Misc.coalesce(checkboxToggled, nearestTheme.checkboxToggled);
		themeWidget.columnGapSize = dev.gamekit.utils.Misc.coalesce(columnGapSize, nearestTheme.columnGapSize);
		themeWidget.columnMainAxisAlignment = dev.gamekit.utils.Misc.coalesce(columnMainAxisAlignment, nearestTheme.columnMainAxisAlignment);
		themeWidget.columnCrossAxisAlignment = dev.gamekit.utils.Misc.coalesce(columnCrossAxisAlignment, nearestTheme.columnCrossAxisAlignment);
		themeWidget.fieldDefaultBackground = dev.gamekit.utils.Misc.coalesce(fieldDefaultBackground, nearestTheme.fieldDefaultBackground);
		themeWidget.fieldFocusBackground = dev.gamekit.utils.Misc.coalesce(fieldFocusBackground, nearestTheme.fieldFocusBackground);
		themeWidget.fieldPadding = dev.gamekit.utils.Misc.coalesce(fieldPadding, nearestTheme.fieldPadding);
		themeWidget.fieldText = dev.gamekit.utils.Misc.coalesce(fieldText, nearestTheme.fieldText);
		themeWidget.fieldFont = dev.gamekit.utils.Misc.coalesce(fieldFont, nearestTheme.fieldFont);
		themeWidget.fieldFontSize = dev.gamekit.utils.Misc.coalesce(fieldFontSize, nearestTheme.fieldFontSize);
		themeWidget.fieldFontHeightRatio = dev.gamekit.utils.Misc.coalesce(fieldFontHeightRatio, nearestTheme.fieldFontHeightRatio);
		themeWidget.fieldFontStyle = dev.gamekit.utils.Misc.coalesce(fieldFontStyle, nearestTheme.fieldFontStyle);
		themeWidget.fieldColor = dev.gamekit.utils.Misc.coalesce(fieldColor, nearestTheme.fieldColor);
		themeWidget.fieldBackgroundColor = dev.gamekit.utils.Misc.coalesce(fieldBackgroundColor, nearestTheme.fieldBackgroundColor);
		themeWidget.fieldAlignment = dev.gamekit.utils.Misc.coalesce(fieldAlignment, nearestTheme.fieldAlignment);
		themeWidget.fieldShadowEnabled = dev.gamekit.utils.Misc.coalesce(fieldShadowEnabled, nearestTheme.fieldShadowEnabled);
		themeWidget.fieldShadowOffsetX = dev.gamekit.utils.Misc.coalesce(fieldShadowOffsetX, nearestTheme.fieldShadowOffsetX);
		themeWidget.fieldShadowOffsetY = dev.gamekit.utils.Misc.coalesce(fieldShadowOffsetY, nearestTheme.fieldShadowOffsetY);
		themeWidget.fieldShadowColor = dev.gamekit.utils.Misc.coalesce(fieldShadowColor, nearestTheme.fieldShadowColor);
		themeWidget.flexGapSize = dev.gamekit.utils.Misc.coalesce(flexGapSize, nearestTheme.flexGapSize);
		themeWidget.flexMainAxisAlignment = dev.gamekit.utils.Misc.coalesce(flexMainAxisAlignment, nearestTheme.flexMainAxisAlignment);
		themeWidget.flexCrossAxisAlignment = dev.gamekit.utils.Misc.coalesce(flexCrossAxisAlignment, nearestTheme.flexCrossAxisAlignment);
		themeWidget.gapWidth = dev.gamekit.utils.Misc.coalesce(gapWidth, nearestTheme.gapWidth);
		themeWidget.gapHeight = dev.gamekit.utils.Misc.coalesce(gapHeight, nearestTheme.gapHeight);
		themeWidget.gridColumnCount = dev.gamekit.utils.Misc.coalesce(gridColumnCount, nearestTheme.gridColumnCount);
		themeWidget.gridColumnGapSize = dev.gamekit.utils.Misc.coalesce(gridColumnGapSize, nearestTheme.gridColumnGapSize);
		themeWidget.gridRowGapSize = dev.gamekit.utils.Misc.coalesce(gridRowGapSize, nearestTheme.gridRowGapSize);
		themeWidget.imageFit = dev.gamekit.utils.Misc.coalesce(imageFit, nearestTheme.imageFit);
		themeWidget.imageInterpolation = dev.gamekit.utils.Misc.coalesce(imageInterpolation, nearestTheme.imageInterpolation);
		themeWidget.opacityOpacity = dev.gamekit.utils.Misc.coalesce(opacityOpacity, nearestTheme.opacityOpacity);
		themeWidget.paddingPadding = dev.gamekit.utils.Misc.coalesce(paddingPadding, nearestTheme.paddingPadding);
		themeWidget.panelBackground = dev.gamekit.utils.Misc.coalesce(panelBackground, nearestTheme.panelBackground);
		themeWidget.panelColor = dev.gamekit.utils.Misc.coalesce(panelColor, nearestTheme.panelColor);
		themeWidget.panelCornerRadius = dev.gamekit.utils.Misc.coalesce(panelCornerRadius, nearestTheme.panelCornerRadius);
		themeWidget.panelClip = dev.gamekit.utils.Misc.coalesce(panelClip, nearestTheme.panelClip);
		themeWidget.progressTrackBackground = dev.gamekit.utils.Misc.coalesce(progressTrackBackground, nearestTheme.progressTrackBackground);
		themeWidget.progressFillBackground = dev.gamekit.utils.Misc.coalesce(progressFillBackground, nearestTheme.progressFillBackground);
		themeWidget.progressFillMargin = dev.gamekit.utils.Misc.coalesce(progressFillMargin, nearestTheme.progressFillMargin);
		themeWidget.progressFillMode = dev.gamekit.utils.Misc.coalesce(progressFillMode, nearestTheme.progressFillMode);
		themeWidget.progressMinValue = dev.gamekit.utils.Misc.coalesce(progressMinValue, nearestTheme.progressMinValue);
		themeWidget.progressMaxValue = dev.gamekit.utils.Misc.coalesce(progressMaxValue, nearestTheme.progressMaxValue);
		themeWidget.progressValue = dev.gamekit.utils.Misc.coalesce(progressValue, nearestTheme.progressValue);
		themeWidget.rowGapSize = dev.gamekit.utils.Misc.coalesce(rowGapSize, nearestTheme.rowGapSize);
		themeWidget.rowMainAxisAlignment = dev.gamekit.utils.Misc.coalesce(rowMainAxisAlignment, nearestTheme.rowMainAxisAlignment);
		themeWidget.rowCrossAxisAlignment = dev.gamekit.utils.Misc.coalesce(rowCrossAxisAlignment, nearestTheme.rowCrossAxisAlignment);
		themeWidget.scaledScale = dev.gamekit.utils.Misc.coalesce(scaledScale, nearestTheme.scaledScale);
		themeWidget.sizedUseIntrinsicWidth = dev.gamekit.utils.Misc.coalesce(sizedUseIntrinsicWidth, nearestTheme.sizedUseIntrinsicWidth);
		themeWidget.sizedUseIntrinsicHeight = dev.gamekit.utils.Misc.coalesce(sizedUseIntrinsicHeight, nearestTheme.sizedUseIntrinsicHeight);
		themeWidget.sizedFractionalWidth = dev.gamekit.utils.Misc.coalesce(sizedFractionalWidth, nearestTheme.sizedFractionalWidth);
		themeWidget.sizedFractionalHeight = dev.gamekit.utils.Misc.coalesce(sizedFractionalHeight, nearestTheme.sizedFractionalHeight);
		themeWidget.sizedFixedWidth = dev.gamekit.utils.Misc.coalesce(sizedFixedWidth, nearestTheme.sizedFixedWidth);
		themeWidget.sizedFixedHeight = dev.gamekit.utils.Misc.coalesce(sizedFixedHeight, nearestTheme.sizedFixedHeight);
		themeWidget.sliderThumbBackground = dev.gamekit.utils.Misc.coalesce(sliderThumbBackground, nearestTheme.sliderThumbBackground);
		themeWidget.sliderThumbWidth = dev.gamekit.utils.Misc.coalesce(sliderThumbWidth, nearestTheme.sliderThumbWidth);
		themeWidget.sliderThumbHeight = dev.gamekit.utils.Misc.coalesce(sliderThumbHeight, nearestTheme.sliderThumbHeight);
		themeWidget.sliderTrackBackground = dev.gamekit.utils.Misc.coalesce(sliderTrackBackground, nearestTheme.sliderTrackBackground);
		themeWidget.sliderFillBackground = dev.gamekit.utils.Misc.coalesce(sliderFillBackground, nearestTheme.sliderFillBackground);
		themeWidget.sliderFillMargin = dev.gamekit.utils.Misc.coalesce(sliderFillMargin, nearestTheme.sliderFillMargin);
		themeWidget.sliderFillMode = dev.gamekit.utils.Misc.coalesce(sliderFillMode, nearestTheme.sliderFillMode);
		themeWidget.sliderMinValue = dev.gamekit.utils.Misc.coalesce(sliderMinValue, nearestTheme.sliderMinValue);
		themeWidget.sliderMaxValue = dev.gamekit.utils.Misc.coalesce(sliderMaxValue, nearestTheme.sliderMaxValue);
		themeWidget.sliderValue = dev.gamekit.utils.Misc.coalesce(sliderValue, nearestTheme.sliderValue);
		themeWidget.textText = dev.gamekit.utils.Misc.coalesce(textText, nearestTheme.textText);
		themeWidget.textFont = dev.gamekit.utils.Misc.coalesce(textFont, nearestTheme.textFont);
		themeWidget.textFontSize = dev.gamekit.utils.Misc.coalesce(textFontSize, nearestTheme.textFontSize);
		themeWidget.textFontHeightRatio = dev.gamekit.utils.Misc.coalesce(textFontHeightRatio, nearestTheme.textFontHeightRatio);
		themeWidget.textFontStyle = dev.gamekit.utils.Misc.coalesce(textFontStyle, nearestTheme.textFontStyle);
		themeWidget.textColor = dev.gamekit.utils.Misc.coalesce(textColor, nearestTheme.textColor);
		themeWidget.textBackgroundColor = dev.gamekit.utils.Misc.coalesce(textBackgroundColor, nearestTheme.textBackgroundColor);
		themeWidget.textAlignment = dev.gamekit.utils.Misc.coalesce(textAlignment, nearestTheme.textAlignment);
		themeWidget.textShadowEnabled = dev.gamekit.utils.Misc.coalesce(textShadowEnabled, nearestTheme.textShadowEnabled);
		themeWidget.textShadowOffsetX = dev.gamekit.utils.Misc.coalesce(textShadowOffsetX, nearestTheme.textShadowOffsetX);
		themeWidget.textShadowOffsetY = dev.gamekit.utils.Misc.coalesce(textShadowOffsetY, nearestTheme.textShadowOffsetY);
		themeWidget.textShadowColor = dev.gamekit.utils.Misc.coalesce(textShadowColor, nearestTheme.textShadowColor);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<ThemeConfig> { }
}