package dev.gamekit.ui.widgets;

public class AlignConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public dev.gamekit.ui.enums.Alignment horizontalAlignment;
	public dev.gamekit.ui.enums.Alignment verticalAlignment;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof AlignConfig alignConfig
			&& java.util.Objects.equals(horizontalAlignment, alignConfig.horizontalAlignment)
			&& java.util.Objects.equals(verticalAlignment, alignConfig.verticalAlignment)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Align alignWidget = (dev.gamekit.ui.widgets.Align) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		alignWidget.horizontalAlignment = dev.gamekit.utils.Misc.coalesce(horizontalAlignment, nearestTheme.alignHorizontalAlignment);
		alignWidget.verticalAlignment = dev.gamekit.utils.Misc.coalesce(verticalAlignment, nearestTheme.alignVerticalAlignment);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<AlignConfig> { }
}