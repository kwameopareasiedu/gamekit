package dev.gamekit.ui.widgets;

public class GapConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public java.lang.Integer width;
	public java.lang.Integer height;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof GapConfig gapConfig
			&& java.util.Objects.equals(width, gapConfig.width)
			&& java.util.Objects.equals(height, gapConfig.height)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Gap gapWidget = (dev.gamekit.ui.widgets.Gap) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		gapWidget.width = dev.gamekit.utils.Misc.coalesce(width, nearestTheme.gapWidth);
		gapWidget.height = dev.gamekit.utils.Misc.coalesce(height, nearestTheme.gapHeight);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<GapConfig> { }
}