package dev.gamekit.ui.widgets;

public class RowConfig extends dev.gamekit.ui.widgets.FlexConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public java.lang.Integer gapSize;
	public dev.gamekit.ui.enums.MainAxisAlignment mainAxisAlignment;
	public dev.gamekit.ui.enums.CrossAxisAlignment crossAxisAlignment;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof RowConfig rowConfig
			&& java.util.Objects.equals(gapSize, rowConfig.gapSize)
			&& java.util.Objects.equals(mainAxisAlignment, rowConfig.mainAxisAlignment)
			&& java.util.Objects.equals(crossAxisAlignment, rowConfig.crossAxisAlignment)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Row rowWidget = (dev.gamekit.ui.widgets.Row) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		rowWidget.gapSize = dev.gamekit.utils.Misc.coalesce(gapSize, nearestTheme.rowGapSize);
		rowWidget.mainAxisAlignment = dev.gamekit.utils.Misc.coalesce(mainAxisAlignment, nearestTheme.rowMainAxisAlignment);
		rowWidget.crossAxisAlignment = dev.gamekit.utils.Misc.coalesce(crossAxisAlignment, nearestTheme.rowCrossAxisAlignment);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<RowConfig> { }
}