package dev.gamekit.ui.widgets;

public class RotatedConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public java.lang.Double rotation;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof RotatedConfig rotatedConfig
			&& java.util.Objects.equals(rotation, rotatedConfig.rotation)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Rotated rotatedWidget = (dev.gamekit.ui.widgets.Rotated) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		rotatedWidget.rotation = rotation;
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<RotatedConfig> { }
}