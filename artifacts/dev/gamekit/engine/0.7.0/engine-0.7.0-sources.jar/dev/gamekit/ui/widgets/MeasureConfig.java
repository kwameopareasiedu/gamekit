package dev.gamekit.ui.widgets;

public class MeasureConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public java.lang.Boolean showRuler;
	public java.lang.Integer rulerTicks;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof MeasureConfig measureConfig
			&& java.util.Objects.equals(showRuler, measureConfig.showRuler)
			&& java.util.Objects.equals(rulerTicks, measureConfig.rulerTicks)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Measure measureWidget = (dev.gamekit.ui.widgets.Measure) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		measureWidget.showRuler = showRuler;
		measureWidget.rulerTicks = rulerTicks;
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<MeasureConfig> { }
}