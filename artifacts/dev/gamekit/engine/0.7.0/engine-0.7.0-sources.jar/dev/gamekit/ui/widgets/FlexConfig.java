package dev.gamekit.ui.widgets;

public class FlexConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public java.lang.Integer gapSize;
	public dev.gamekit.ui.enums.MainAxisAlignment mainAxisAlignment;
	public dev.gamekit.ui.enums.CrossAxisAlignment crossAxisAlignment;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof FlexConfig flexConfig
			&& java.util.Objects.equals(gapSize, flexConfig.gapSize)
			&& java.util.Objects.equals(mainAxisAlignment, flexConfig.mainAxisAlignment)
			&& java.util.Objects.equals(crossAxisAlignment, flexConfig.crossAxisAlignment)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Flex flexWidget = (dev.gamekit.ui.widgets.Flex) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		flexWidget.gapSize = dev.gamekit.utils.Misc.coalesce(gapSize, nearestTheme.flexGapSize);
		flexWidget.mainAxisAlignment = dev.gamekit.utils.Misc.coalesce(mainAxisAlignment, nearestTheme.flexMainAxisAlignment);
		flexWidget.crossAxisAlignment = dev.gamekit.utils.Misc.coalesce(crossAxisAlignment, nearestTheme.flexCrossAxisAlignment);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<FlexConfig> { }
}