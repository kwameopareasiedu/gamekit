package dev.gamekit.ui.widgets;

public class ImageConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public dev.gamekit.utils.EngineImage image;
	public dev.gamekit.ui.enums.ImageFit fit;
	public dev.gamekit.settings.ImageInterpolation interpolation;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ImageConfig imageConfig
			&& java.util.Objects.equals(image, imageConfig.image)
			&& java.util.Objects.equals(fit, imageConfig.fit)
			&& java.util.Objects.equals(interpolation, imageConfig.interpolation)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Image imageWidget = (dev.gamekit.ui.widgets.Image) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		imageWidget.image = image;
		imageWidget.fit = dev.gamekit.utils.Misc.coalesce(fit, nearestTheme.imageFit);
		imageWidget.interpolation = dev.gamekit.utils.Misc.coalesce(interpolation, nearestTheme.imageInterpolation);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<ImageConfig> { }
}