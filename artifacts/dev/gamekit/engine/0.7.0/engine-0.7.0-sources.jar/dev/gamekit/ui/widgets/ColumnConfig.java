package dev.gamekit.ui.widgets;

public class ColumnConfig extends dev.gamekit.ui.widgets.FlexConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public java.lang.Integer gapSize;
	public dev.gamekit.ui.enums.MainAxisAlignment mainAxisAlignment;
	public dev.gamekit.ui.enums.CrossAxisAlignment crossAxisAlignment;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ColumnConfig columnConfig
			&& java.util.Objects.equals(gapSize, columnConfig.gapSize)
			&& java.util.Objects.equals(mainAxisAlignment, columnConfig.mainAxisAlignment)
			&& java.util.Objects.equals(crossAxisAlignment, columnConfig.crossAxisAlignment)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Column columnWidget = (dev.gamekit.ui.widgets.Column) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		columnWidget.gapSize = dev.gamekit.utils.Misc.coalesce(gapSize, nearestTheme.columnGapSize);
		columnWidget.mainAxisAlignment = dev.gamekit.utils.Misc.coalesce(mainAxisAlignment, nearestTheme.columnMainAxisAlignment);
		columnWidget.crossAxisAlignment = dev.gamekit.utils.Misc.coalesce(crossAxisAlignment, nearestTheme.columnCrossAxisAlignment);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<ColumnConfig> { }
}