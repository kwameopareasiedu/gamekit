package dev.gamekit.ui.widgets;

public class FieldConfig extends dev.gamekit.ui.widgets.TextConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public dev.gamekit.utils.EngineImage defaultBackground;
	public dev.gamekit.utils.EngineImage focusBackground;
	public dev.gamekit.utils.Spacing padding;
	public dev.gamekit.ui.events.FocusEvent.Handler focusListener;
	public dev.gamekit.ui.events.KeyCharEvent.Handler keyCharListener;
	public dev.gamekit.ui.events.ChangeEvent.Handler<java.lang.String> changeListener;
	public java.lang.String text;
	public java.awt.Font font;
	public java.lang.Integer fontSize;
	public java.lang.Double fontHeightRatio;
	public java.lang.Integer fontStyle;
	public java.awt.Color color;
	public java.awt.Color backgroundColor;
	public dev.gamekit.ui.enums.Alignment alignment;
	public java.lang.Boolean shadowEnabled;
	public java.lang.Integer shadowOffsetX;
	public java.lang.Integer shadowOffsetY;
	public java.awt.Color shadowColor;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof FieldConfig fieldConfig
			&& java.util.Objects.equals(defaultBackground, fieldConfig.defaultBackground)
			&& java.util.Objects.equals(focusBackground, fieldConfig.focusBackground)
			&& java.util.Objects.equals(padding, fieldConfig.padding)
			&& java.util.Objects.equals(text, fieldConfig.text)
			&& java.util.Objects.equals(font, fieldConfig.font)
			&& java.util.Objects.equals(fontSize, fieldConfig.fontSize)
			&& java.util.Objects.equals(fontHeightRatio, fieldConfig.fontHeightRatio)
			&& java.util.Objects.equals(fontStyle, fieldConfig.fontStyle)
			&& java.util.Objects.equals(color, fieldConfig.color)
			&& java.util.Objects.equals(backgroundColor, fieldConfig.backgroundColor)
			&& java.util.Objects.equals(alignment, fieldConfig.alignment)
			&& java.util.Objects.equals(shadowEnabled, fieldConfig.shadowEnabled)
			&& java.util.Objects.equals(shadowOffsetX, fieldConfig.shadowOffsetX)
			&& java.util.Objects.equals(shadowOffsetY, fieldConfig.shadowOffsetY)
			&& java.util.Objects.equals(shadowColor, fieldConfig.shadowColor)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Field fieldWidget = (dev.gamekit.ui.widgets.Field) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		fieldWidget.defaultBackground = dev.gamekit.utils.Misc.coalesce(defaultBackground, nearestTheme.fieldDefaultBackground);
		fieldWidget.focusBackground = dev.gamekit.utils.Misc.coalesce(focusBackground, nearestTheme.fieldFocusBackground);
		fieldWidget.padding = dev.gamekit.utils.Misc.coalesce(padding, nearestTheme.fieldPadding);
		fieldWidget.focusListener = focusListener;
		fieldWidget.keyCharListener = keyCharListener;
		fieldWidget.changeListener = changeListener;
		fieldWidget.text = dev.gamekit.utils.Misc.coalesce(text, nearestTheme.fieldText);
		fieldWidget.font = dev.gamekit.utils.Misc.coalesce(font, nearestTheme.fieldFont);
		fieldWidget.fontSize = dev.gamekit.utils.Misc.coalesce(fontSize, nearestTheme.fieldFontSize);
		fieldWidget.fontHeightRatio = dev.gamekit.utils.Misc.coalesce(fontHeightRatio, nearestTheme.fieldFontHeightRatio);
		fieldWidget.fontStyle = dev.gamekit.utils.Misc.coalesce(fontStyle, nearestTheme.fieldFontStyle);
		fieldWidget.color = dev.gamekit.utils.Misc.coalesce(color, nearestTheme.fieldColor);
		fieldWidget.backgroundColor = dev.gamekit.utils.Misc.coalesce(backgroundColor, nearestTheme.fieldBackgroundColor);
		fieldWidget.alignment = dev.gamekit.utils.Misc.coalesce(alignment, nearestTheme.fieldAlignment);
		fieldWidget.shadowEnabled = dev.gamekit.utils.Misc.coalesce(shadowEnabled, nearestTheme.fieldShadowEnabled);
		fieldWidget.shadowOffsetX = dev.gamekit.utils.Misc.coalesce(shadowOffsetX, nearestTheme.fieldShadowOffsetX);
		fieldWidget.shadowOffsetY = dev.gamekit.utils.Misc.coalesce(shadowOffsetY, nearestTheme.fieldShadowOffsetY);
		fieldWidget.shadowColor = dev.gamekit.utils.Misc.coalesce(shadowColor, nearestTheme.fieldShadowColor);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<FieldConfig> { }
}