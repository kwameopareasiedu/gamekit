package dev.gamekit.ui.widgets;

public class SliderConfig extends dev.gamekit.ui.widgets.ProgressConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public dev.gamekit.utils.EngineImage thumbBackground;
	public java.lang.Integer thumbWidth;
	public java.lang.Integer thumbHeight;
	public dev.gamekit.ui.events.ChangeEvent.Handler<java.lang.Double> changeListener;
	public dev.gamekit.utils.EngineImage trackBackground;
	public dev.gamekit.utils.EngineImage fillBackground;
	public dev.gamekit.utils.Spacing fillMargin;
	public dev.gamekit.ui.widgets.Progress.FillMode fillMode;
	public java.lang.Double minValue;
	public java.lang.Double maxValue;
	public java.lang.Double value;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof SliderConfig sliderConfig
			&& java.util.Objects.equals(thumbBackground, sliderConfig.thumbBackground)
			&& java.util.Objects.equals(thumbWidth, sliderConfig.thumbWidth)
			&& java.util.Objects.equals(thumbHeight, sliderConfig.thumbHeight)
			&& java.util.Objects.equals(trackBackground, sliderConfig.trackBackground)
			&& java.util.Objects.equals(fillBackground, sliderConfig.fillBackground)
			&& java.util.Objects.equals(fillMargin, sliderConfig.fillMargin)
			&& java.util.Objects.equals(fillMode, sliderConfig.fillMode)
			&& java.util.Objects.equals(minValue, sliderConfig.minValue)
			&& java.util.Objects.equals(maxValue, sliderConfig.maxValue)
			&& java.util.Objects.equals(value, sliderConfig.value)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Slider sliderWidget = (dev.gamekit.ui.widgets.Slider) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		sliderWidget.thumbBackground = dev.gamekit.utils.Misc.coalesce(thumbBackground, nearestTheme.sliderThumbBackground);
		sliderWidget.thumbWidth = dev.gamekit.utils.Misc.coalesce(thumbWidth, nearestTheme.sliderThumbWidth);
		sliderWidget.thumbHeight = dev.gamekit.utils.Misc.coalesce(thumbHeight, nearestTheme.sliderThumbHeight);
		sliderWidget.changeListener = changeListener;
		sliderWidget.trackBackground = dev.gamekit.utils.Misc.coalesce(trackBackground, nearestTheme.sliderTrackBackground);
		sliderWidget.fillBackground = dev.gamekit.utils.Misc.coalesce(fillBackground, nearestTheme.sliderFillBackground);
		sliderWidget.fillMargin = dev.gamekit.utils.Misc.coalesce(fillMargin, nearestTheme.sliderFillMargin);
		sliderWidget.fillMode = dev.gamekit.utils.Misc.coalesce(fillMode, nearestTheme.sliderFillMode);
		sliderWidget.minValue = dev.gamekit.utils.Misc.coalesce(minValue, nearestTheme.sliderMinValue);
		sliderWidget.maxValue = dev.gamekit.utils.Misc.coalesce(maxValue, nearestTheme.sliderMaxValue);
		sliderWidget.value = dev.gamekit.utils.Misc.coalesce(value, nearestTheme.sliderValue);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<SliderConfig> { }
}