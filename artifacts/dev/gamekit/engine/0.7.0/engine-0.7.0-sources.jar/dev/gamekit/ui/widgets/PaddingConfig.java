package dev.gamekit.ui.widgets;

public class PaddingConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public dev.gamekit.utils.Spacing padding;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof PaddingConfig paddingConfig
			&& java.util.Objects.equals(padding, paddingConfig.padding)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Padding paddingWidget = (dev.gamekit.ui.widgets.Padding) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		paddingWidget.padding = dev.gamekit.utils.Misc.coalesce(padding, nearestTheme.paddingPadding);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<PaddingConfig> { }
}