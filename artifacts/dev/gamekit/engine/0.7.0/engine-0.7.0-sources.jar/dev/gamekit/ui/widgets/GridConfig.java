package dev.gamekit.ui.widgets;

public class GridConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public java.lang.Integer columnCount;
	public java.lang.Integer columnGapSize;
	public java.lang.Integer rowGapSize;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof GridConfig gridConfig
			&& java.util.Objects.equals(columnCount, gridConfig.columnCount)
			&& java.util.Objects.equals(columnGapSize, gridConfig.columnGapSize)
			&& java.util.Objects.equals(rowGapSize, gridConfig.rowGapSize)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Grid gridWidget = (dev.gamekit.ui.widgets.Grid) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		gridWidget.columnCount = dev.gamekit.utils.Misc.coalesce(columnCount, nearestTheme.gridColumnCount);
		gridWidget.columnGapSize = dev.gamekit.utils.Misc.coalesce(columnGapSize, nearestTheme.gridColumnGapSize);
		gridWidget.rowGapSize = dev.gamekit.utils.Misc.coalesce(rowGapSize, nearestTheme.gridRowGapSize);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<GridConfig> { }
}