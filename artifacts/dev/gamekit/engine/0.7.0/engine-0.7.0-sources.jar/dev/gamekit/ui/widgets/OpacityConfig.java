package dev.gamekit.ui.widgets;

public class OpacityConfig implements dev.gamekit.ui.widgets.Widget.Config {
	public java.lang.Double opacity;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof OpacityConfig opacityConfig
			&& java.util.Objects.equals(opacity, opacityConfig.opacity)
		;
	}

	@Override
	public void updateWidget(dev.gamekit.ui.widgets.Widget widget) {
		dev.gamekit.ui.widgets.Opacity opacityWidget = (dev.gamekit.ui.widgets.Opacity) widget;
		dev.gamekit.ui.widgets.Theme nearestTheme = dev.gamekit.utils.Misc.coalesce(widget.getAncestorOfType(dev.gamekit.ui.widgets.Theme.class), dev.gamekit.ui.widgets.Theme.DEFAULT);

		opacityWidget.opacity = dev.gamekit.utils.Misc.coalesce(opacity, nearestTheme.opacityOpacity);
	}

	@FunctionalInterface
	public interface Updater extends dev.gamekit.ui.widgets.Widget.ConfigUpdater<OpacityConfig> { }
}